import { Component, OnInit } from '@angular/core';
import { AnimalService } from '../../services/animal.service';

@Component({
  selector: 'app-animal',
  templateUrl: './animal.component.html',
  styleUrls: ['./animal.component.css']  // Corrected 'styleUrl' to 'styleUrls'
})
export class AnimalComponent implements OnInit {
  animalList: any[] = [];  // Initialize animalList as an empty array

  constructor(private animalService: AnimalService) {}

  ngOnInit() {
    this.getAllAnimals();  // Call the method on component initialization
  }

  getAllAnimals() {
    this.animalService.getAllAnimalsData().subscribe((data: any[]) => {
      this.animalList = data;  // Update animalList with the received data
    });
  }
}
